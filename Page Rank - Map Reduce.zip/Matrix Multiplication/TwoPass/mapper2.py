#!/usr/bin/env python
# mapper.py

import sys

for line in sys.stdin:
   
    line = line.strip()
    # split the line into words
    data = line.split('\t')
    print '%s\t%s' % (data[0],data[1])
