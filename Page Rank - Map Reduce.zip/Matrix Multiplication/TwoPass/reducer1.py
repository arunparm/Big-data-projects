#!/usr/bin/env python
# reducer.py

import sys

last_key = None
mat1 = []
mat2 = []
for input_line in sys.stdin:
    input_line = input_line.strip()
    if input_line != "":
        (this_key, value) = input_line.split('\t')
        value = value.split(',')
        if last_key == None:
            last_key = this_key
        if last_key == this_key:
            if int(value[0]) == 1: #tag 1 i.e matrix A
                mat1.append([value[1],value[2]])
            else:
                mat2.append([value[1],value[2]])
        else:
            for each_i in mat1:
                for each_k in mat2:
                    print '%s,%s\t%s' % (each_i[0], each_k[0],float(each_i[1])*float(each_k[1]))

            last_key =  this_key
            mat1 =[]
            mat2 = []
            if int(value[0]) == 1: #tag 1 i.e matrix A
                mat1.append([value[1],value[2]])
            else:
                mat2.append([value[1],value[2]])

for each_i in mat1:
    for each_k in mat2:
        print '%s,%s\t%s' % (each_i[0], each_k[0],float(each_i[1])*float(each_k[1]))            
            
            
        
        
    
    
