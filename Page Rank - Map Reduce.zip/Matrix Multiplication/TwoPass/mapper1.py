#!/usr/bin/env python
# mapper.py

import sys
for line in sys.stdin:

    line = line.strip() #getting ride of any extra space
    data = line.split(',') # each line contain Tag,i,j,M[i][j]

    tag = int(data[0])
    row_id = data[1]
    col_id = data[2]
    val = data[3]

    if tag == 1:
        print '%s\t%s,%s,%s' % (col_id, tag,row_id,val)
    else:
        print '%s\t%s,%s,%s' % (row_id, tag,col_id,val)
