#!/usr/bin/env python
# reducer.py

import sys

last_key = None
running_total = 0

for input_line in sys.stdin:
    input_line = input_line.strip()
    if input_line != "":
        (this_key, value) = input_line.split('\t')
        value = float(value)
        if last_key == None:
            last_key = this_key
        if last_key == this_key:
            running_total += value
        else:
            print( "%s\t%s" % (last_key, running_total) )
            running_total = value           
            last_key =  this_key

if last_key == this_key:
    print( "%s\t%s" % (last_key, running_total) )  
