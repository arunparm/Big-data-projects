#!/usr/bin/env python
# reducer.py
import sys

last_key = None
Dict1 = {}
Dict2 = {}
for line in sys.stdin:
    line = line.strip()
    if line != "":
        (this_key, value) = line.split("\t")
        this_key = this_key.split(' ')
        value = value.split(',')

        #First Iteration
        if last_key == None:
            last_key = this_key

        # Log values - Must keep track of key changes
        if last_key == this_key:
            if int(value[0]) == 1:
                Dict1[int(value[1])] = float(value[2])    
            else:
                Dict2[int(value[1])] = float(value[2])
        else:
            n = len(Dict1.keys())
            result = 0
            for j in range(n):
                try:
                    result += Dict1[j] * Dict2[j]
                except:
                    quit()
            print '%s,%s\t%s' % (last_key[0],last_key[1],result)
            last_key =  this_key
            Dict1.clear()       # Clear dicts
            Dict2.clear()
            
            if int(value[0]) == 1:
                Dict1[int(value[1])] = float(value[2])    
            else:
                Dict2[int(value[1])] = float(value[2])
                
n = len(Dict1.keys())
result = 0
for j in range(n):
    try:
        result += Dict1[j] * Dict2[j]
    except:
        quit()
print '%s,%s\t%s' % (last_key[0],last_key[1],result)

