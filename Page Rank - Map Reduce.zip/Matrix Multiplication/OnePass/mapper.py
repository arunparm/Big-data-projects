#!/usr/bin/env python
# mapper.py

import sys
row1 = 100
col1 = 100
row2 = 100
col2 = 100

for line in sys.stdin:
    line = line.strip()
    data = line.split(',')

#    if data[0] == '#':
 #       if int(data[1]) == 1:
  #          row1 = int(data[2])
   #         col1 = int(data[3])
   #     else:
   #         row2 = int(data[2])
   #         col2 = int(data[3])
    #    continue
    tag = int(data[0])
    row_id = data[1]
    col_id = data[2]
    val = data[3]

    if tag == 1:
        for k in range(col2):
            print '%s\t%s,%s,%s' % (row_id + ' ' + str(k),tag,col_id,val)
    else:
        for i in range(row1):
            print '%s\t%s,%s,%s' % (str(i) + ' ' +col_id,tag,row_id,val)
    
