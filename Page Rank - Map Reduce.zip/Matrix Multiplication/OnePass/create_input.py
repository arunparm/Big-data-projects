#!/usr/bin/env python

import sys
import random


data = sys.stdin.readline()
data = data.split(" ")
data  = list(data)
rows = int(data[0])
cols = int(data[1])
tag = int(data[2])

#name= '/mnt/scratch/u0877456/matrix2/input'

name = 'C:/Python27/Pass_One/input/input'
file_name = name+str(tag)
f = open(file_name,'wb')
#s = '#,'  + str(tag) + ',' + str(rows) + ',' + str(cols) + '\n'
#f.write(s)
for i in range (0,rows):
    for j in range(0,cols):
        val = random.uniform(0,1000)
        s = str(tag) + ',' + str(i) + ',' + str(j) + ',' + str(val) + '\n'
        f.write(s)
f.close()



          
    
